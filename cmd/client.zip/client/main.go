package main

// import (
//
//	"context"
//	"log"
//	"net/http"
//
//	"connectrpc.com/connect"
//	// Use the following imports when generating from proto files using 'buf generate'.
//	// helloworldv1 "github.com/abitofhelp/bzlmod/internal/gen/abitofhelp/helloworld/v1"
//	// "github.com/abitofhelp/bzlmod/internal/gen/abitofhelp/helloworld/v1/helloworldv1connect"
//	// Use the following imports when generating from proto files using Bazel build.
//	//helloworldv1 "github.com/abitofhelp/bzlmod/bazel-bin/proto/abitofhelp/helloworld/v1/abitofhelp_helloworld_v1_go_proto_/github.com/abitofhelp/bzlmod/proto/abitofhelp/helloworld/v1"
//	// FIXME: "github.com/abitofhelp/bzlmod/bazel-bin/proto/abitofhelp/helloworld/v1/abitofhelp_helloworld_v1_go_proto_/github.com/abitofhelp/bzlmod/proto/abitofhelp/helloworld/v1/helloworldconnect"
//
// )
func main() {
	//	client := helloworldv1connect.NewGreeterServiceClient(
	//		http.DefaultClient,
	//		"http://localhost:8080",
	//	)
	//	res, err := client.SayHello(
	//		context.Background(),
	//		connect.NewRequest(&helloworldv1.SayHelloRequest{Name: "Jane"}),
	//	)
	//	if err != nil {
	//		log.Println(err)
	//		return
	//	}
	//	log.Println(res.Msg.Message)
}
